﻿// Write your Javascript code.

// Bootstrap tooltip
$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
});

