
Testovací aplikace adresář na platformě MVC .NETCore
====================================================
Narychlo sesmolil Ondřej Mihula


Pro vytvoření databází SQLite spustit v příkazovém řádku 
-------------------------------------------------------

- dotnet ef database update --context ApplicationDbContext 
- dotnet ef database update --context AddressBookDbContext

nebo spustit "DB-Update.cmd"

Při prvním spuštení je vytvořena demo databáze a uživatel 
---------------------------------------------------------

- login: demo@demo.org
- heslo: Abcd.1234
